#La nostra prima funzione in python

#Nome=input("Come ti chiami?")
#Eta=input("Quanti anni hai?")

#print("Il tuo nome è: " +Nome +", la tua età è: " +Eta + " anni")

###

#Numero_1=input("Inserisci numero1: ")
#Numero_2=input("Inserisci numero2: ")
#Numero_3=input("Inserisci numero3: ")

#Numero1=int(Numero_1)
#Numero2=int(Numero_2)
#Numero3=int(Numero_3)
#
#if (Numero1>=Numero2) and (Numero1>=Numero3):
#    print("Il numero più grande è il numero1")

#elif (Numero2>=Numero3) and (Numero2>=Numero1):
#    print("Il numero più grande è il numero2")

#elif (Numero3>=Numero1) and (Numero3>=Numero1):
#    print("Il numero più grande è il numero3")

###

import somma,sottrazione,moltiplicazione,divisione
#domanda=True
while True:
    risposta=input("vuoi fare una operazione? S/N? ")
    if risposta=="N":
        break
    elif risposta=="S":
        operazione=input("Che operazione vuoi fare? Somma/Sottrazione/Moltiplicazione/Divisione?")
        num1=int(input("Inserisci primo numero: "))
        num2=int(input("Inserisci secondo numero: "))
        if operazione=="Somma":
            risultato=somma.somma(num1,num2)
            print(risultato)
        if operazione=="Sottrazione":
            risultato=sottrazione.sottrazione(num1,num2)
            print(risultato)
        if operazione=="Moltiplicazione":
            risultato=moltiplicazione.moltiplicazione(num1,num2)
            print(risultato)
        if operazione=="Divisione":
            risultato=divisione.divisione(num1,num2)
            print(risultato)
            

