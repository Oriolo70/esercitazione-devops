def moltiplicazione(numero1,numero2):
    risultato = numero1*numero2
    return risultato